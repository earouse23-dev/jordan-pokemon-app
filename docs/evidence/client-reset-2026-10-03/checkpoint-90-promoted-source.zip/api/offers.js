import { pkmnPricesRequests } from "../lib/pkmnprices-requests.js";
import { withNativeCors } from "../lib/native-cors.js";
import { fetchPkmnPricesOffers } from "../lib/providers/pkmnprices.js";
import { serverEnvironment } from "../lib/env.js";

const SAFE_TEXT = /^[\p{L}\p{N} .:'&+\-/()#]{1,120}$/u;
const windows = new Map();

function isRateLimited(request) {
  const forwarded = String(request.headers?.["x-forwarded-for"] || "")
    .split(",")[0]
    .trim();
  const key = forwarded || request.socket?.remoteAddress || "unknown";
  const now = Date.now();
  const current = windows.get(key);
  if (!current || now - current.startedAt >= 60_000) {
    windows.set(key, { startedAt: now, count: 1 });
    return false;
  }
  current.count += 1;
  return current.count > 20;
}

function send(response, status, body, headers = {}) {
  response.setHeader("Cache-Control", "no-store");
  for (const [key, value] of Object.entries(headers))
    response.setHeader(key, value);
  return response.status(status).json(body);
}

function requestParameter(request, name) {
  if (request.url) {
    try {
      return new URL(request.url, "https://mica.local").searchParams.get(name);
    } catch {
      // Fall through to the test/dev request shape.
    }
  }
  const value = request.query?.[name];
  return Array.isArray(value) ? value[0] : value;
}

function parseLookup(request) {
  let raw;
  try {
    raw = JSON.parse(String(requestParameter(request, "lookup") || "{}"));
  } catch {
    return null;
  }
  const lookup = {
    clientId: String(raw?.clientId || "").trim(),
    pkmnpricesId: String(raw?.pkmnpricesId || "").trim(),
    tcgplayerId: String(raw?.tcgplayerId || "").trim(),
    name: String(raw?.name || "").trim(),
    set: String(raw?.set || "").trim(),
    number: String(raw?.number || "").trim(),
    language: String(raw?.language || "en")
      .trim()
      .toLowerCase(),
    condition: String(raw?.condition || "").trim(),
    variant: String(raw?.variant || "Normal").trim(),
  };
  const direct =
    /^\d{1,12}$/.test(lookup.pkmnpricesId) ||
    /^\d{1,12}$/.test(lookup.tcgplayerId);
  const search =
    SAFE_TEXT.test(lookup.name) &&
    (!lookup.set || SAFE_TEXT.test(lookup.set)) &&
    (!lookup.number || SAFE_TEXT.test(lookup.number));
  const filters =
    /^[a-z-]{2,8}$/.test(lookup.language) &&
    (!lookup.condition || SAFE_TEXT.test(lookup.condition)) &&
    SAFE_TEXT.test(lookup.variant);
  return lookup.clientId && filters && (direct || search) ? lookup : null;
}

async function handler(request, response) {
  if (request.method !== "GET") {
    response.setHeader("Allow", "GET");
    return send(response, 405, { error: "Method not allowed" });
  }
  if (isRateLimited(request))
    return send(
      response,
      429,
      { error: "Too many marketplace requests. Try again shortly." },
      { "Retry-After": "60" },
    );
  const lookup = parseLookup(request);
  if (!lookup)
    return send(response, 400, { error: "Provide one valid card lookup." });
  const config = serverEnvironment();
  const apiKey = config.pkmnpricesApiKey;
  if (!apiKey)
    return send(response, 503, {
      error: "Live marketplace offers are not configured.",
      code: "provider_unconfigured",
      provider: "pkmnprices",
      capability: "asking_prices",
      capabilityStatus: "unsupported",
    });

  if (!(await pkmnPricesRequests.authenticate(request, response))) return;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 9_000);
  try {
    const result = await fetchPkmnPricesOffers(
      apiKey,
      lookup,
      controller.signal,
    );
    return send(
      response,
      200,
      {
        clientId: lookup.clientId,
        providerCardId: result.cardId,
        offers: result.offers,
        statuses: result.statuses,
        capability: "asking_prices",
        capabilityStatus: Object.values(result.statuses).some(
          (status) => status === "live",
        )
          ? "live"
          : Object.values(result.statuses).every(
                (status) => status === "plan_required",
              )
            ? "unsupported"
            : "missing",
        retrievedAt: new Date().toISOString(),
      },
      {
        "Cache-Control": "no-store",
        "CDN-Cache-Control": "no-store",
      },
    );
  } catch (error) {
    console.error("[api/offers] provider request failed", {
      status: error?.status || null,
      name: error?.name || "Error",
    });
    if (error?.status === 403)
      return send(response, 403, {
        error:
          "The current PkmnPrices key does not have access to marketplace offers.",
        code: "provider_plan_required",
        provider: "pkmnprices",
        capability: "asking_prices",
        capabilityStatus: "unsupported",
      });
    const status = error?.status === 429 ? 429 : 502;
    return send(response, status, {
      error:
        status === 429
          ? "The marketplace-provider rate limit was reached."
          : "Marketplace offers are temporarily unavailable.",
      code: status === 429 ? "provider_rate_limited" : "provider_unavailable",
      provider: "pkmnprices",
      capability: "asking_prices",
      capabilityStatus: status === 429 ? "rate_limited" : "provider_error",
    });
  } finally {
    clearTimeout(timeout);
  }
}

export { handler as retainedHandler };
export default withNativeCors(handler, ["GET"]);
