import{d as p}from"./chunk-7UP7ZM55.js";var o=p("App",{web:()=>import("./web-ATOL7VBZ.js").then(e=>new e.AppWeb)});export{o as App};
