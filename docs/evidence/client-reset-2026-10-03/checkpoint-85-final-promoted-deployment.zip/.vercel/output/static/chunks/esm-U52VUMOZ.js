import{d as e}from"./chunk-7UP7ZM55.js";var t=e("Preferences",{web:()=>import("./web-RVRYV7KN.js").then(r=>new r.PreferencesWeb)});export{t as Preferences};
