import{d as p}from"./chunk-7UP7ZM55.js";import"./chunk-IUFDSBGV.js";var o=p("App",{web:()=>import("./web-GIHVZDBN.js").then(e=>new e.AppWeb)});export{o as App};
