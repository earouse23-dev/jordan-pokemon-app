import{d as e}from"./chunk-7UP7ZM55.js";import"./chunk-IUFDSBGV.js";var t=e("Preferences",{web:()=>import("./web-B3HCCM6Z.js").then(r=>new r.PreferencesWeb)});export{t as Preferences};
